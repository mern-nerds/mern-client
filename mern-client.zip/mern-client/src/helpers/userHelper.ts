export function formatUserName(name) {
  return name.trim().toUpperCase();
}

export const APP_NAME = "MyMERNApp 🥭";

export function isAdmin(user) {
  return user?.isAdmin === true;
}