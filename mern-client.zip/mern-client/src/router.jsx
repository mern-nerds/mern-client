import { createRouter, RouterProvider, createRootRoute, createRoute } from '@tanstack/react-router';
import App from './App';
import Home from './routes/home';
import Login from './routes/login';
import Profile from './routes/Profile';
import About from './routes/about';

// Create root route
const rootRoute = createRootRoute({
  component: App
});

// Create other routes
const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: Home
});

const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/login',
  component: Login
});

const profileRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/profile',
  component: Profile
});

const aboutRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/about',
  component: About
});

// Create the route tree
const routeTree = rootRoute.addChildren([
  homeRoute,
  loginRoute,
  profileRoute,
  aboutRoute
]);

// Create the router
const router = createRouter({
  routeTree
});

export default function Router() {
  return <RouterProvider router={router} />;
}