export default function About() {
  return <div>About page — powered by mangoes 🥭</div>
}
