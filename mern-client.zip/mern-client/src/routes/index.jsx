export default function Index() {
  return <div>Welcome to the home page 🥭</div>
}
