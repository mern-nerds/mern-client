// src/routes/Profile.jsx
import React from "react";
import { useUser } from "../context/userContext";

// Helper functions moved into component file
function formatUserName(name) {
  return name?.trim().toUpperCase() || '';
}

const APP_NAME = "MyMERNApp 🥭";

function isAdmin(user) {
  return user?.isAdmin === true;
}

export default function profile() {
  const { user } = useUser();

  if (!user) return <div>Please login to see your profile.</div>;

  return (
    <div>
      <h1>{APP_NAME}</h1>
      <p>Name: {formatUserName(user.name)}</p>
      <p>Email: {user.email}</p>
      <p>Password: {user.password}</p>
      <p>Admin: {isAdmin(user) ? "Yes" : "No"}</p>
    </div>
  );
}