// src/store.js
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './features/user/userSlice'; // adjust this to your actual slice path

export const store = configureStore({
  reducer: {
    user: userReducer,
  },
});
